module test
	(
	input			logic								clk_i,
	input			logic								rst_i,
	input			logic								a_i,
	output		logic								a_o,
	output		logic								b_o
	);


	// set & reset state
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			a_o <= 0;
			b_o <= 0;
		end else begin
			b_o <= a_o;
			//
			a_o <= a_i;
			//
			b_o <= a_o;
			//
			a_o <= ~a_i;
			//
			//b_o <= a_o;
		end
	end


endmodule

