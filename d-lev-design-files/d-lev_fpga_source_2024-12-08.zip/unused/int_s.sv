/*
--------------------------------------------------------------------------------

Module: int_s.sv

Function: 
- Signed integrator with output latch.

Instantiates: 
- Nothing.

Notes:
- Internal functioning is signed.

--------------------------------------------------------------------------------
*/

module int_s
	#(
	parameter										DATA_W			= 4	// input width
	)
	(
	// clocks & resets
	input		logic									clk_i,					// clock
	input		logic									rst_i,					// async reset, active high
	// data interface
	input		logic									ltch_i,					// rise=latch output
	input		logic		[DATA_W-1:0]			data_i,					// input data
	output	logic		[DATA_W-1:0]			data_o					// output data
	);


	/*
	----------------------
	-- internal signals --
	----------------------
	*/
	logic		signed	[DATA_W-1:0]			accum;
	logic												ltch_r;


	/*
	================
	== code start ==
	================
	*/

	// accumulate
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			accum <= 0;
		end else begin
			accum <= accum + $signed( data_i );
		end
	end
	
	// latch output
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			ltch_r <= 0;
			data_o <= 0;
		end else begin
			ltch_r <= ltch_i;
			if ( ltch_i && ~ltch_r ) begin  // rising edge
				data_o <= accum;
			end
		end
	end

endmodule
