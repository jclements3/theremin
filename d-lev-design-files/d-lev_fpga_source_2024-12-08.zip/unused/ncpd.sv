/*
--------------------------------------------------------------------------------

Module: ncpd.sv

Function: 
- Forms a numerically controlled periodic delay.

Instantiates:
- (1x) lfsr.sv

Notes:
- Output period = period_i / clk_i.
- Parameterized period_i integer and fractional widths.
- Optional sq_o dithering with LFSR noise for huge increase in SFDR.
- Set LFSR_W = 0 to disable dither.
- Set PERIOD_W > FRAC_W.

--------------------------------------------------------------------------------
*/

module ncpd
	#(
	parameter										PERIOD_W				= 32,	// period_i width
	parameter										FRAC_W				= 24,	// period_i fractional width
	parameter										LFSR_W				= 12	// LFSR shift register width, 3 to 168, 0 to disable
	)
	(
	// clocks & resets
	input		logic									clk_i,						// clock
	input		logic									rst_i,						// async reset, active high
	// inputs
	input		logic		[PERIOD_W-1:0]			period_i,					// period of 1/2 cycle
	// outputs
	output	logic									edge_o,						// edge flag
	output	logic									sq_o							// square output
	);


	/*
	----------------------
	-- internal signals --
	----------------------
	*/
	localparam										ACCUM_W = 1+PERIOD_W;
	logic					[ACCUM_W-1:0]			in_sel, in_sub, accum;


	/*
	================
	== code start ==
	================
	*/
	
	// select input value
	always_comb in_sel = ( edge_o ) ? period_i : 0;
	
	// subtract 1.0 from integer portion and register
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			in_sub <= 0;
		end else begin
			in_sub <= in_sel - ACCUM_W'(1 << FRAC_W);
		end
	end

	// accumulate
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			accum <= 0;
		end else begin
			accum <= accum + in_sub;
		end
	end

	generate

		//////////////
		// DITHERED //
		//////////////
		if ( LFSR_W ) begin

			// signals
			logic					[FRAC_W-1:0]		noise_s, noise_u;
			logic					[ACCUM_W-1:0]		dith;
			logic											noise_en;
			logic											noise_bit;
			logic					[1:0]					msb_sr;

			// instantiate lfsr
			lfsr
			#(
			.LFSR_W			( LFSR_W ),
			.FULL_SEQ		( 0 )
			)
			lfsr_inst
			(
			.*,
			.en_i				( noise_en ),
			.vect_o			(  ),  // unused
			.bit_o			( noise_bit )
			);

			// vectorize (to make LFSR_W independent of FRAC_W)
			always_ff @ ( posedge clk_i or posedge rst_i ) begin
				if ( rst_i ) begin
					noise_s <= 0;
				end else if ( noise_en ) begin
					noise_s <= FRAC_W'( { noise_s, noise_bit } );
				end
			end

			// signed to unsigned
			always_comb noise_u = { ~noise_s[FRAC_W-1], noise_s[FRAC_W-2:0] };

			// dither
			always_comb dith = accum + noise_u;

			// register msb
			always_ff @ ( posedge clk_i or posedge rst_i ) begin
				if ( rst_i ) begin
					msb_sr <= 0;
				end else begin
					msb_sr <= 2'( { msb_sr, dith[ACCUM_W-1] } );
				end
			end

			// decode flag
			always_comb edge_o = ( msb_sr == 1 );
	
			// register / toggle
			always_ff @ ( posedge clk_i or posedge rst_i ) begin
				if ( rst_i ) begin
					sq_o <= 0;
					noise_en <= 0;
				end else begin
					sq_o <= ( edge_o ) ? ~sq_o : sq_o;
					noise_en <= edge_o;
				end
			end


		//////////////////
		// NOT DITHERED //
		//////////////////
		end else begin

			logic  msb, msb_r;

			// assign for clarity
			always_comb msb = accum[ACCUM_W-1];

			// register msb
			always_ff @ ( posedge clk_i or posedge rst_i ) begin
				if ( rst_i ) begin
					msb_r <= 0;
				end else begin
					msb_r <= msb;
				end
			end

			// decode flag
			always_comb edge_o = msb & ~msb_r;
	
			// toggle clock
			always_ff @ ( posedge clk_i or posedge rst_i ) begin
				if ( rst_i ) begin
					sq_o <= 0;
				end else begin
					sq_o <= ( edge_o ) ? ~sq_o : sq_o;
				end
			end

		end

	endgenerate

endmodule 