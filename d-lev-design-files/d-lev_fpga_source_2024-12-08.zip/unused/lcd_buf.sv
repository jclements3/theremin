/*
--------------------------------------------------------------------------------

Module: lcd_buf.sv

Function: 
- LCD module interface w/ optional data buffering.

Instantiates:
- (1x) lcd.sv
  - (1x) ddfs.sv
- (1x) fifo_buf.sv
if (FIFO_ADDR_W != 0):
- (1x) fifo.sv
  - (2x) bin_gray_bin.sv
  - (2x) pipe.sv
  - (1x) ram_dp.sv
else:
- (1x) ss_buf.sv

Notes:
- See individual components for details.

--------------------------------------------------------------------------------
*/

module lcd_buf
	#(
	parameter	int						LCD_W					= 4,		// lcd_data_o width (bits)
	parameter	real						CLK_HZ				= 160000000,	// system clock rate (Hz)
	parameter	real						LCD_HZ				= 190000,		// LCD board clock rate (Hz)
	parameter								FIFO_ADDR_W			= 10		// FIFO address width (bits); 0=no FIFO
	)
	(
	// clocks & resets
	input		logic							clk_i,							// clock
	input		logic							rst_i,							// async. reset, active high
	// register set interface
	input		logic							rsn_i,							// 0=data|addr; 1=command
	input		logic	[LCD_W*2-1:0]		data_i,							// parallel data in
	input		logic							wr_i,								// write, active hi
	output	logic							wr_rdy_o,						// write ready, active hi
	// LCD interface
	output	logic							lcd_rs_o,						// 0=command; 1=data|addr
	output	logic	[LCD_W-1:0]			lcd_data_o,						// parallel data out
	output	logic							lcd_e_o							// enable strobe, active high
	);


	/*
	----------------------
	-- internal signals --
	----------------------
	*/	
	localparam								FIFO_W				= 1+(LCD_W*2);
	logic				[FIFO_W-1:0]		wr_data, rd_data;
	logic										rd, rd_rdy;

	
	/*
	================
	== code start ==
	================
	*/


	// combine write data
	always_comb wr_data = { rsn_i, data_i };


	// tx fifo
	fifo_buf
	#(
	.DATA_W				( FIFO_W ),
	.ADDR_W				( FIFO_ADDR_W ),
	.SYNC_W				( 0 ),
	.PROT_WR				( 0 ),
	.PROT_RD				( 0 ),
	.REG_OUT				( 1 )  // for speed-up
	)
	lcd_fifo_buf_inst
	(
	.*,
	.wr_clk_i			( clk_i ),
	.rd_clk_i			( clk_i ),
	.wr_data_i			( wr_data ),
	.rd_data_o			( rd_data ),
	.rd_i					( rd ),
	.rd_rdy_o			( rd_rdy )
	);

			
	// LCD interface
	lcd
	#(
	.LCD_W				( LCD_W ),
	.CLK_HZ				( CLK_HZ ),
	.LCD_HZ				( LCD_HZ )
	)
	lcd_inst
	(
	.*,
	.rsn_i				( rd_data[FIFO_W-1] ),
	.data_i				( rd_data[FIFO_W-2:0] ),
	.rd_rdy_i			( rd_rdy ),
	.rd_o					( rd )
	);

	
endmodule
