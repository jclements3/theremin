/*
--------------------------------------------------------------------------------

Module: phase_det.sv

Function: 
- Forms a simple quadrature phase detector for a PLL.

Instantiates:
- Nothing.

Notes:
- Normal operation is zero_i rise => quad_i rise => zero_i fall => quad_i fall.
- Noise is somewhat tolerated at the zero_i input.
- Noise is highly tolerated at the quad_i input.
- Output phase (0) when quad_i lags zero_i by 90 degrees.
- Output phase (-) when quad_i lags zero_i by < 90 degrees (early).
- Output phase (+) when quad_i lags zero_i by > 90 degrees (late).
- Gain is 4 clocks output error per one clock input offset error.
- Limiting of pe_o is enabled when COUNT_W > PE_W.
   
--------------------------------------------------------------------------------
*/

module phase_det
	#(
	parameter											COUNT_W				= 6,		// count width (bits)
	parameter											PE_W					= 4,		// phase error width (bits)
	parameter											SYNC_W				= 2,		// resync registers, 1 min
	parameter											DEGL_W				= 4		// deglitch registers, 1 min
	)
	(
	// clocks & resets
	input		logic										clk_i,							// clock
	input		logic										rst_i,							// async. reset, active hi
	// I/O
	input		logic										max_i,							// 1=force max output
	input		logic										min_i,							// 1=force min output
	input		logic										zero_i,							// zero async input
	input		logic										quad_i,							// quadrature async input, delayed 90 degrees when locked
	output	logic				[PE_W-1:0]			pe_o,								// phase error (from 90 degrees, signed), updated w/ pe_new_o
	output	logic										pe_new_o,						// phase error new, active hi one clock
	// debug
	output	logic										lim_o,							// pe_o is limited, active hi one clock
	output	logic										roll_o							// counter roll over/ under (error), active hi
	);


	/*
	----------------------
	-- internal signals --
	----------------------
	*/
	localparam											ZERO_W = DEGL_W + SYNC_W;
	localparam	signed								PE_MAX = (2**(PE_W-1))-1;
	localparam	signed								PE_MIN = -(2**(PE_W-1));
	//
	logic							[ZERO_W-1:0]		zero_sr;
	logic							[SYNC_W-1:0]		quad_sr;
	logic			signed		[COUNT_W-1:0]		pe_count, inc_dec_val;
	logic													xor_f, new_f, max_f, min_f, lim_f, roll_f;
	logic							[1:0]					msbs, msbs_r;


	/*
	================
	== code start ==
	================
	*/


	// register to resync 
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			zero_sr <= 0;
			quad_sr <= 0;
		end else begin
			zero_sr <= ZERO_W'( { zero_sr, zero_i } );
			quad_sr <= SYNC_W'( { quad_sr, quad_i } );
		end
	end

	// deglitch & detect rising edge
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			new_f <= 0;
		end else begin
			new_f <= ( zero_sr[ZERO_W-1:SYNC_W-1] == 1 );
		end
	end

	// xor, calculate inc_dec_val
	always_comb xor_f = ( zero_sr[SYNC_W-1] ^ quad_sr[SYNC_W-1] );
	always_comb inc_dec_val = ( xor_f ) ? COUNT_W'( 1 ) : COUNT_W'( -1 );
	
	// flag max / min
	always_comb max_f = ( pe_count > PE_MAX ) || max_i;
	always_comb min_f = ( pe_count < PE_MIN ) || min_i;
	
	// form the phase up/down counter, handle output
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			pe_count <= 0;
			pe_o <= 0;
			pe_new_o <= 0;
		end else begin  // load counter with offset at start/end
			if ( new_f ) begin
				pe_count <= inc_dec_val;
				pe_o <= ( max_f ) ? PE_W'( PE_MAX ) : ( min_f ) ? PE_W'( PE_MIN ) : PE_W'( pe_count );
				pe_new_o <= '1;
			end else begin
				pe_count <= pe_count + inc_dec_val;
				pe_new_o <= 0;
			end
		end
	end


	/*
	===========
	== debug ==
	===========
	*/

	// flag under / over flow, limit
	always_comb msbs = pe_count[COUNT_W-1:COUNT_W-2];
	always_comb roll_f = ( msbs == ~msbs_r ) && ^msbs_r;
	always_comb lim_f = ( max_f || min_f );

	// register & output errors
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			msbs_r <= 0;
			roll_o <= 0;
			lim_o <= 0;
		end else begin
			msbs_r <= msbs;
			roll_o <= roll_f;
			lim_o <= ( new_f ) ? lim_f : 0;
		end
	end

endmodule
