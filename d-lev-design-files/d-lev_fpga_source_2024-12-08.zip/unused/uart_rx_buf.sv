/*
--------------------------------------------------------------------------------

Module: uart_rx_buf

Function: 
- Forms the RX side of a DATA_W,n,1 RS232 UART w/ optional FIFO.

Instantiates:
- (1x) uart_rx.sv
  - (1x) ddfs.sv
- (1x) fifo_buf.sv
if (FIFO_ADDR_W != 0):
- (1x) fifo.sv
  - (2x) bin_gray_bin.sv
  - (2x) pipe.sv
  - (1x) ram_dp.sv
else:
- (1x) ss_buf.sv

Notes:
- Parameterized FIFO option / depth.
- See individual components for details.

--------------------------------------------------------------------------------
*/

module uart_rx_buf
	#(
	parameter								DATA_W				= 8,		// parallel data width (bits)
	parameter								SYNC_W 				= 2,		// number of resync regs (1 or larger)
	parameter	real						CLK_HZ				= 160000000,	// system clock rate (Hz)
	parameter	real						BAUD_HZ				= 115200,	// baud rate (Hz)
	parameter								FIFO_ADDR_W			= 0		// FIFO address width (bits); 0=no FIFO
	)
	(
	// clocks & resets
	input		logic							clk_i,							// clock
	input		logic							rst_i,							// async. reset, active hi
	// register set interface
	output	logic	[DATA_W-1:0]		rd_data_o,						// data
	input		logic							rd_i,								// data read, active hi
	output	logic							rd_rdy_o,						// data ready, active hi
	// serial interface
	input		logic							rx_i,								// serial data
	// debug
	output	logic							line_err_o,						// bad start|stop, active hi
	output	logic							wr_err_o							// write error, active hi
	);


	/*
	----------------------
	-- internal signals --
	----------------------
	*/
	logic				[DATA_W-1:0]		wr_data;
	logic										wr, wr_rdy;


	/*
	================
	== code start ==
	================
	*/

	// rx fifo / buf
	fifo_buf
	#(
	.DATA_W				( DATA_W ),
	.ADDR_W				( FIFO_ADDR_W ),
	.SYNC_W				( 0 ),
	.PROT_WR				( 0 ),
	.PROT_RD				( 0 ),
	.REG_OUT				( 1 )  // for speed-up
	)
	uart_rx_fifo_buf_inst
	(
	.*,
	.wr_clk_i			( clk_i ),
	.wr_data_i			( wr_data ),
	.wr_i					( wr ),
	.wr_rdy_o			( wr_rdy ),
	.rd_clk_i			( clk_i )
	);


	// uart_rx
	uart_rx
	#(
	.DATA_W				( DATA_W ),
	.SYNC_W 				( SYNC_W ),
	.CLK_HZ				( CLK_HZ ),
	.BAUD_HZ				( BAUD_HZ )
	)
	uart_rx_inst
	(
	.*,
	.wr_rdy_i			( wr_rdy ),
	.wr_o					( wr ),
	.data_o				( wr_data )
	);
			

endmodule
