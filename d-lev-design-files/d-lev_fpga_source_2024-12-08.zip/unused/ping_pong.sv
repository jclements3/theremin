/*
--------------------------------------------------------------------------------

Module: ping_pong.sv

Function: 
- Alternate outputs for filter bank enables.

Instantiates: 
- Nothing.

Notes:
- None.
    
--------------------------------------------------------------------------------
*/

module ping_pong
	(
	input		logic									clk_i,					// clock
	input		logic									rst_i,					// async reset, active hi
	output	logic									en_a_o,
	output	logic									en_b_o
	);


	/*
	----------------------
	-- internal signals --
	----------------------
	*/
	logic												en_a, en_b;


	/*
	================
	== code start ==
	================
	*/


	// flip & register
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			en_a <= 0;
			en_b <= 0;
		end else begin
			en_a <= ~en_a;
			en_b <=  en_a;
		end
	end
	
	// output
	always_comb en_a_o = en_a;
	always_comb en_b_o = en_b;
	
	
endmodule
