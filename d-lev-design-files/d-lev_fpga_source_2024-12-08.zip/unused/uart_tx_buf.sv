/*
--------------------------------------------------------------------------------

Module: uart_tx_buf

Function: 
- Forms the TX side of a DATA_W,n,STOP_BITS RS232 UART w/ optional FIFO.

Instantiates:
- (1x) uart_tx.sv
  - (1x) ddfs.sv
- (1x) fifo_buf.sv
if (FIFO_ADDR_W != 0):
- (1x) fifo.sv
  - (2x) bin_gray_bin.sv
  - (2x) pipe.sv
  - (1x) ram_dp.sv
else:
- (1x) ss_buf.sv

Notes:
- Parameterized FIFO option / depth.
- See individual components for details.

--------------------------------------------------------------------------------
*/

module uart_tx_buf
	#(
	parameter								DATA_W				= 8,		// parallel data width (bits)
	parameter								STOP_BITS 			= 1,		// number of stop bits
	parameter	real						CLK_HZ				= 160000000,	// system clock rate (Hz)
	parameter	real						BAUD_HZ				= 115200,	// baud rate (Hz)
	parameter								FIFO_ADDR_W			= 10		// FIFO address width (bits); 0=no FIFO
	)
	(
	// clocks & resets
	input		logic							clk_i,							// clock
	input		logic							rst_i,							// async. reset, active hi
	// register set interface
	input		logic	[DATA_W-1:0]		wr_data_i,						// data
	input		logic							wr_i,								// write, active hi
	output	logic							wr_rdy_o,						// write ready, active hi
	// serial interface
	output	logic							tx_o								// serial data
	);


	/*
	----------------------
	-- internal signals --
	----------------------
	*/
	logic				[DATA_W-1:0]		rd_data;
	logic										rd, rd_rdy;


	/*
	================
	== code start ==
	================
	*/


	// tx fifo / buf
	fifo_buf
	#(
	.DATA_W				( DATA_W ),
	.ADDR_W				( FIFO_ADDR_W ),
	.SYNC_W				( 0 ),
	.PROT_WR				( 0 ),
	.PROT_RD				( 0 ),
	.REG_OUT				( 1 )  // for speed-up
	)
	uart_tx_fifo_buf_inst
	(
	.*,
	.wr_clk_i			( clk_i ),
	.rd_clk_i			( clk_i ),
	.rd_data_o			( rd_data ),
	.rd_i					( rd ),
	.rd_rdy_o			( rd_rdy )
	);
			

	// uart_tx
	uart_tx
	#(
	.DATA_W				( DATA_W ),
	.STOP_BITS 			( STOP_BITS ),
	.CLK_HZ				( CLK_HZ ),
	.BAUD_HZ				( BAUD_HZ )
	)
	uart_tx_inst
	(
	.*,
	.rd_rdy_i			( rd_rdy ),
	.rd_o					( rd ),
	.data_i				( rd_data )
	);


endmodule
