/*
--------------------------------------------------------------------------------

Module: noise_mult.sv

Function: 
- Forms a dynamically scaled noise source.

Instantiates:
- (1x) lfsr.sv

Notes:
- Optional limit reps with REPS != 0.
- If REPS = 1 then run when en_i = 1.
- If REPS = 0 or REPS >= DATA_W then run DATA_W clocks @ en_i pulse.
- If REPS < DATA_W then run REPS clocks @ en_i pulse.
- Optional differentiated output with DIFF = 1.
- Optional signed output with SGN = 1.

--------------------------------------------------------------------------------
*/

module noise_mult
	#(
	parameter										DATA_W				= 8,	// data width (bits)
	parameter										LFSR_W				= 8,	// LFSR shift register width, 3 to 168
	parameter										BPSK					= 0,	// 1=BPSK encoding of noise bit
	parameter										REPS					= 0,	// reps value (0=no limit)
	parameter										DIFF					= 1,	// 1=differentiate output
	parameter										SGN					= 0	// 1=signed output
	)
	(
	// clocks & resets
	input		logic									clk_i,						// clock
	input		logic									rst_i,						// async reset, active high
	// I/O
	input		logic									en_i,							// enable, active high
	output	logic									new_o,						// done, active high
	input		logic		[DATA_W-1:0]			data_i,						// data to multiply (unsigned)
	output	logic		[DATA_W+DIFF-1:0]		noise_o						// noise
	);


	/*
	----------------------
	-- internal signals --
	----------------------
	*/
	logic										lfsr_bit, noise_bit;
	//
	logic				[DATA_W-1:0]		noise_sr, noise_u;
	logic				[DATA_W:0]			noise_nxt;  // extra bit
	logic										busy_f;
	logic										max_f, new_f;


	/*
	================
	== code start ==
	================
	*/


	// instantiate lfsr
	lfsr
	#(
	.LFSR_W			( LFSR_W ),
	.FULL_SEQ		( 0 )
	)
	lfsr_inst
	(
	.*,
	.en_i				( busy_f ),
	.vect_o			(  ),  // unused
	.bit_o			( lfsr_bit )
	);

	
	generate
		if ( BPSK ) begin  // BPSK

			logic tog_f;
			
			always_ff @ ( posedge clk_i or posedge rst_i ) begin
				if ( rst_i ) begin
					tog_f <= 0;
					noise_bit <= 0;
				end else begin
					tog_f <= ( busy_f ) ? ~tog_f : tog_f;
					noise_bit <= ( lfsr_bit || tog_f ) ? ~noise_bit : noise_bit;
				end
			end
			
		end else begin  // no BPSK
		
			always_comb noise_bit = lfsr_bit;
			
		end
	endgenerate
			
	
	// do add
	always_comb noise_nxt = ( noise_bit ) ? noise_sr + data_i : noise_sr;

	// do add & shift noise multiplication
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			noise_sr <= 0;
		end else if ( busy_f ) begin
			noise_sr <= DATA_W'( noise_nxt >> 1 );
		end
	end

	// register flag
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			new_f <= 0;
		end else begin
			new_f <= max_f;
		end
	end

	
	// optional counter
	generate
		if ( REPS != 1 ) begin  // need counter

			localparam								BIT_MAX 				= ( REPS && ( REPS < DATA_W ) ) ? REPS-1 : DATA_W-1 ;
			localparam								BIT_W 				= $clog2( BIT_MAX+1 );
			logic				[BIT_W-1:0]			bit_c, bit_c_nxt;

			// do modulo add
			always_comb bit_c_nxt = ( max_f ) ? 1'b0 : bit_c + 1'b1;

			// form the bit_c up-counter
			always_ff @ ( posedge clk_i or posedge rst_i ) begin
				if ( rst_i ) begin
					bit_c <= 0;
				end else if ( busy_f ) begin
					bit_c <= bit_c_nxt;
				end
			end

			// decode flags
			always_comb busy_f = ( |bit_c || en_i );
			always_comb max_f = ( bit_c == BIT_MAX );
		
		end else begin  // no counter

			always_comb busy_f = en_i;
			always_comb max_f = en_i;
			
		end
	endgenerate


	// optional noise reg & output reg
	generate
		if ( ( REPS != 1 ) || DIFF ) begin  // need regs

			always_ff @ ( posedge clk_i or posedge rst_i ) begin
				if ( rst_i ) begin
					new_o <= 0;
					noise_u <= 0;
				end else begin
					new_o <= new_f;
					if ( new_f ) begin
						noise_u <= noise_sr;
					end
				end
			end

		end else begin  // no regs
		
			always_comb new_o = new_f;
			always_comb noise_u = noise_sr;

		end
	endgenerate

	
	// optional differentiation
	generate
		if ( DIFF ) begin

			logic		[DATA_W:0]			diff_s;  // extra bit

			// reg outputs
			always_ff @ ( posedge clk_i or posedge rst_i ) begin
				if ( rst_i ) begin
					diff_s <= 0;
				end else begin
					if ( new_f ) begin
						diff_s <= noise_sr - noise_u;
					end
				end
			end

			// convert signed / unsigned
			always_comb noise_o = ( SGN ) ? diff_s : { ~diff_s[DATA_W], diff_s[DATA_W-1:0] };

		end else begin

			// convert signed / unsigned
			always_comb noise_o = ( SGN ) ? { ~noise_u[DATA_W-1], noise_u[DATA_W-2:0] } : noise_u;

		end
	endgenerate


endmodule 