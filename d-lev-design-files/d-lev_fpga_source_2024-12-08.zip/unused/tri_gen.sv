/*
--------------------------------------------------------------------------------

Module: tri_gen

Function: 
- Generates triangle wave (signed)

Instantiates:
- Nothing.

Notes:
- None.

--------------------------------------------------------------------------------
*/

module tri_gen
	#(
	// input params, ok to change:
	parameter										DIV_W					= 12,	// clock divider width (bits)
	parameter										SHL_W					= 3,	// left shift width (bits)
	parameter										TRI_W					= DIV_W-1+(1<<SHL_W)-1	// output width (don't change!)
	)
	(
	// clocks & resets
	input		logic									clk_i,						// clock
	input		logic									rst_i,						// async. reset, active hi
	// interface
	input		logic		[SHL_W-1:0]				shl_i,						// left shift (gain)
	output	logic		[TRI_W-1:0]				tri_o							// triangle out (sgn)
	);


	/*
	----------------------
	-- internal signals --
	----------------------
	*/
	logic					[DIV_W-1:0]				div;
	logic		signed	[DIV_W-2:0]				tri_r;



	/*
	================
	== code start ==
	================
	*/


	// form the up-counter
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			div <= 0;
		end else begin
			div <= div + 1'b1;
		end
	end

	// decode & register, shift & register, output
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			tri_r <= 0;
			tri_o <= 0;
		end else begin
			tri_r <= ( div[DIV_W-1] ^ div[DIV_W-2] ) ? ~div[DIV_W-2:0] : div[DIV_W-2:0];
			tri_o <= tri_r <<< shl_i;
		end
	end

endmodule
