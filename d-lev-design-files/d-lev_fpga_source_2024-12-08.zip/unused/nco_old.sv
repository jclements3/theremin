/*
--------------------------------------------------------------------------------

Module: nco.sv

Function: 
- Forms a numerically controlled oscillator (NCO).

Instantiates:
- (1x) noise_mult.sv
  - (1x) lfsr.sv
- (1x) ddr_out_altera.sv (if O_DDR=1)

Notes:
- Output frequency = clk_i * freq_i / (2^DIV_W).
- Dithering with LFSR noise for huge increase in SFDR.
- Set freq_i LSbs to one via LSV for even better SFDR.

--------------------------------------------------------------------------------
*/

module nco
	#(
	parameter										ACCUM_W				= 16,	// accumulator width (bits)
	parameter										DIV_W					= 12,	// nco divide width (bits)
	parameter										FREQ_W				= 8,	// frequency width (bits)
	parameter										DITH_W				= 8,	// dither mult width (bits)
	parameter										REPS					= 0,  // dither shift reps
	parameter										DIFF					= 1,  // dither differentiate enable
	parameter										SGN					= 0,  // dither signed enable
	parameter										LFSR_W				= 8,	// dither LFSR shift register width, 3 to 168
	parameter										LSV					= 1,	// least significant bits constant value, 0 to disable
	parameter										O_DDR					= 1	// 1=use ddr at output; 0=no ddr
	)
	(
	// clocks & resets
	input		logic									clk_i,						// clock
	input		logic									rst_i,						// async reset, active high
	// I/O
	input		logic				[FREQ_W-1:0]	freq_i,						// frequency
	input		logic				[DITH_W-1:0]	dith_i,						// dither multiplier
	output	logic				[ACCUM_W-1:0]	accum_o,						// accumulator
	output	logic									edge_o,						// 1=edge, undithered
	output	logic									sq_o							// dithered square output
	);


	/*
	----------------------
	-- internal signals --
	----------------------
	*/
	localparam										LSV_W 				= $clog2(LSV+1);
	localparam										NOISE_W				= DITH_W+DIFF;
	logic							[FREQ_W-1:0]	freq;
	logic							[DIV_W-1:0]		div, dith;
	logic							[NOISE_W-1:0]	noise;
	logic												msb_r;
	logic												edge_f, fall_f;


	/*
	================
	== code start ==
	================
	*/


	// LSb constant value
	always_comb freq = FREQ_W'( { freq_i, LSV_W'(LSV) } );

	// modulo unsigned accumulate
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			div <= 0;
			msb_r <= 0;
			edge_o <= 0;
		end else begin
			div <= div + freq;
			msb_r <= div[DIV_W-1];
			edge_o <= edge_f;
		end
	end
	
	// decode flag
	always_comb edge_f = msb_r ^ div[DIV_W-1];
	always_comb fall_f = msb_r && ~div[DIV_W-1];

	
	// speed up wide accum (break the carry chain)
	generate
		if ( ACCUM_W > DIV_W ) begin
			// inc & register
			always_ff @ ( posedge clk_i or posedge rst_i ) begin
				if ( rst_i ) begin
					accum_o <= 0;
				end else begin
					if ( fall_f ) begin
						accum_o[ACCUM_W-1:DIV_W] <= accum_o[ACCUM_W-1:DIV_W] + 1'b1;
					end
					accum_o[DIV_W-1:0] <= div;
				end
			end
		end else begin
			always_comb accum_o = div;
		end
	endgenerate
	
	
	// generate dither noise
	noise_mult
	#(
	.DATA_W			( DITH_W ),
	.LFSR_W			( LFSR_W ),
	.BPSK				( 0 ),
	.REPS				( REPS ),
	.DIFF				( DIFF ),
	.SGN				( SGN )
	)
	noise_mult_inst
	(
	.*,
	.en_i				( edge_o ),
	.new_o			(  ),  // unused
	.data_i			( dith_i ),
	.noise_o			( noise )
	);

	
	generate
		if ( O_DDR ) begin  // DDR @ output

			// declare stuff
			logic							[DIV_W-1:0]		sub;
			logic												sq_0, sq_1;

			// dither, re-register msbs
			always_ff @ ( posedge clk_i or posedge rst_i ) begin
				if ( rst_i ) begin
					dith <= 0;
					sq_0 <= 0;
					sq_1 <= 0;
				end else begin
					dith <= DIV_W'( div + noise );
					sq_1 <= dith[DIV_W-1];
					sq_0 <= sub[DIV_W-1];
				end
			end

			// subtract 1/2 freq
			always_comb sub = DIV_W'( dith - ( freq >> 1 ) );


			// ddr processing
			ddr_out_altera ddr_out
			(
			.*,
			.ddr_i		( { sq_1, sq_0 } ),
			.ddr_o		( sq_o )
			);


		end else begin  // no DDR @ output
		
			// dither
			always_comb dith = DIV_W'( div + noise );
			
			// register
			always_ff @ ( posedge clk_i or posedge rst_i ) begin
				if ( rst_i ) begin
					sq_o <= 0;
				end else begin
					sq_o <= dith[DIV_W-1];
				end
			end

		end
	endgenerate

	
endmodule 