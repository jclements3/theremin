/*
--------------------------------------------------------------------------------

Module: ci_u.sv

Function: 
- Cascade of unsigned integrators with output latch.

Instantiates: 
- Nothing.

Notes:
- Output is latched when 0=>1 change is seeen at ltch_i.
- Internal functioning is unsigned.

--------------------------------------------------------------------------------
*/

module ci_u
	#(
	parameter										DATA_W			= 4,	// I/O width
	parameter										ORDER				= 1	// order (0 to disable)
	)
	(
	// clocks & resets
	input		logic									clk_i,					// clock
	input		logic									rst_i,					// async reset, active high
	// data interface
	input		logic									ltch_i,					// rise=latch output
	input		logic		[DATA_W-1:0]			data_i,					// input data
	output	logic		[DATA_W-1:0]			data_o					// output data
	);


	/*
	----------------------
	-- internal signals --
	----------------------
	*/
	logic					[DATA_W-1:0]			sel_out;
	logic												ltch_r;
	genvar											g;


	/*
	================
	== code start ==
	================
	*/


	// generate regs pipeline
	generate
		if ( ORDER ) begin  // accum

			// internal signals
			logic [DATA_W-1:0] accum[0:ORDER-1];
			logic [DATA_W-1:0] sel_in;

			// assign last to first
			for ( g=ORDER-1; g>=0; g=g-1 ) begin : loop
			
				// select accum input
				always_comb sel_in <= ( g ) ? accum[g-1] : data_i;

				// do accum & reg
				always_ff @ ( posedge clk_i or posedge rst_i ) begin
					if ( rst_i ) begin
						accum[g] <= 0;
					end else begin
						accum[g] <= accum[g] + sel_in;
					end
				end
			end

			// assign output
			always_comb sel_out = accum[ORDER-1];

		end else begin  // no accum

			// assign output
			always_comb sel_out = data_i;

		end
	endgenerate

	
	// latch output on edge
	always_ff @ ( posedge clk_i or posedge rst_i ) begin
		if ( rst_i ) begin
			ltch_r <= 0;
			data_o <= 0;
		end else begin
			ltch_r <= ltch_i;
			if ( ltch_i && ~ltch_r ) begin  // rising edge
				data_o <= sel_out;
			end
		end
	end

	
endmodule
